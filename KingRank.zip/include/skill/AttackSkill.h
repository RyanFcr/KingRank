#ifndef ATTACK_SKILL_H_
#define ATTACK_SKILL_H_

#include "Skill.h"

class AttackSkill : public Skill {
private:
    int damageValue; // 伤害
};

#endif // ATTACK_SKILL_H_